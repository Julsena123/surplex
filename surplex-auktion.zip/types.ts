
export enum CarStatus {
  AVAILABLE = 'Available',
  PENDING = 'Pending',
  SOLD = 'Sold'
}

export interface CarSale {
  id: string;
  make: string;
  model: string;
  year: number;
  vin: string;
  arrivalDate: string; // Nuvežimo Data
  auctionNo: string;   // Aukciono Nr.
  purchasePrice: number; // Min Kaina (Cost)
  status: CarStatus;
  saleDate?: string;     // Parduota data
  salePrice?: number;    // Parduota Kaina
  fees: number;
  notes?: string;
  imageUrl?: string;
}

export interface SalesStats {
  totalProfit: number;
  totalRevenue: number;
  avgProfitPerCar: number;
  soldCount: number;
  inventoryCount: number;
}

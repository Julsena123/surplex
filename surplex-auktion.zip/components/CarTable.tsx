
import React, { useState } from 'react';
import { Edit2, Trash2, Search, Filter, Camera } from 'lucide-react';
import { CarSale, CarStatus } from '../types';

interface CarTableProps {
  sales: CarSale[];
  onEdit: (car: CarSale) => void;
  onDelete: (id: string) => void;
}

export const CarTable: React.FC<CarTableProps> = ({ sales, onEdit, onDelete }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('All');

  const filteredSales = sales.filter(sale => {
    const searchStr = `${sale.make} ${sale.model} ${sale.vin}`.toLowerCase();
    const matchesSearch = searchStr.includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'All' || sale.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return '-';
    return new Date(dateStr).toLocaleDateString('de-DE');
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
      <div className="p-4 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
          <input 
            type="text" 
            placeholder="Search make, model or VIN..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>
        <div className="flex items-center space-x-2">
          <Filter className="text-slate-400 w-5 h-5" />
          <select 
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="border border-slate-200 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 bg-white"
          >
            <option value="All">All Statuses</option>
            {Object.values(CarStatus).map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50 text-slate-500 text-xs font-semibold uppercase tracking-wider">
              <th className="px-6 py-4">Vehicle</th>
              <th className="px-6 py-4">VIN</th>
              <th className="px-6 py-4">Arrival (Nuvežimo)</th>
              <th className="px-6 py-4">Auction #</th>
              <th className="px-6 py-4">Min Price</th>
              <th className="px-6 py-4">Sale (Parduota)</th>
              <th className="px-6 py-4">Status</th>
              <th className="px-6 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredSales.map(sale => {
              const profit = sale.salePrice ? (sale.salePrice - sale.purchasePrice - sale.fees) : null;
              
              return (
                <tr key={sale.id} className="hover:bg-slate-50 transition-colors group">
                  <td className="px-6 py-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 rounded-lg bg-slate-100 flex-shrink-0 overflow-hidden border border-slate-200">
                        {sale.imageUrl ? (
                          <img src={sale.imageUrl} className="w-full h-full object-cover" alt="Car" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-slate-300">
                            <Camera className="w-5 h-5" />
                          </div>
                        )}
                      </div>
                      <div className="flex flex-col">
                        <span className="font-bold text-slate-900 leading-tight">{sale.year} {sale.make}</span>
                        <span className="text-sm text-slate-600 leading-tight">{sale.model}</span>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-xs font-mono text-slate-500">
                    {sale.vin}
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-600">
                    {formatDate(sale.arrivalDate)}
                  </td>
                  <td className="px-6 py-4 text-sm font-semibold text-slate-700">
                    {sale.auctionNo || '-'}
                  </td>
                  <td className="px-6 py-4 font-semibold text-slate-900">
                    ${sale.purchasePrice.toLocaleString()}
                  </td>
                  <td className="px-6 py-4">
                    {sale.salePrice ? (
                      <div className="flex flex-col">
                        <span className="text-sm font-bold text-emerald-600">${sale.salePrice.toLocaleString()}</span>
                        <span className="text-xs text-slate-400">{formatDate(sale.saleDate)}</span>
                      </div>
                    ) : (
                      <span className="text-sm text-slate-300">Not Sold</span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-lg text-[10px] font-bold uppercase ${
                      sale.status === CarStatus.SOLD ? 'bg-emerald-100 text-emerald-700' :
                      sale.status === CarStatus.PENDING ? 'bg-amber-100 text-amber-700' :
                      'bg-blue-100 text-blue-700'
                    }`}>
                      {sale.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button onClick={() => onEdit(sale)} className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg"><Edit2 className="w-4 h-4" /></button>
                      <button onClick={() => onDelete(sale.id)} className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

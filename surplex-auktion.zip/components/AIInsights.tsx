
import React, { useState } from 'react';
import { Sparkles, Loader2, ChevronRight } from 'lucide-react';
import { CarSale } from '../types';
import { analyzeSales } from '../services/gemini';

interface AIInsightsProps {
  sales: CarSale[];
}

export const AIInsights: React.FC<AIInsightsProps> = ({ sales }) => {
  const [loading, setLoading] = useState(false);
  const [insight, setInsight] = useState<string | null>(null);

  const getInsights = async () => {
    if (sales.length === 0) return;
    setLoading(true);
    const result = await analyzeSales(sales);
    setInsight(result);
    setLoading(false);
  };

  return (
    <div className="bg-gradient-to-br from-indigo-600 to-blue-700 p-6 rounded-2xl shadow-xl text-white">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <Sparkles className="w-6 h-6 text-indigo-200" />
          <h2 className="text-xl font-bold tracking-tight">AI Sales Advisor</h2>
        </div>
        {!insight && !loading && (
          <button 
            onClick={getInsights}
            className="px-4 py-2 bg-white/20 hover:bg-white/30 rounded-lg font-semibold transition-all flex items-center space-x-2"
          >
            <span>Analyze Portfolio</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        )}
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-8 space-x-3">
          <Loader2 className="w-6 h-6 animate-spin text-white/70" />
          <span className="font-medium text-white/70">Consulting industry data...</span>
        </div>
      ) : insight ? (
        <div className="space-y-4">
          <div className="bg-white/10 p-5 rounded-xl border border-white/10 backdrop-blur-sm animate-in fade-in slide-in-from-bottom-2">
            <div className="prose prose-invert max-w-none text-indigo-50">
              <div className="whitespace-pre-wrap leading-relaxed">
                {insight}
              </div>
            </div>
          </div>
          <button 
            onClick={getInsights}
            className="text-sm font-medium text-indigo-200 hover:text-white transition-colors"
          >
            Refresh Insights
          </button>
        </div>
      ) : (
        <p className="text-indigo-100">
          Ready to optimize your auction strategy? Click analyze to get data-driven tips based on your current inventory and sales history.
        </p>
      )}
    </div>
  );
};

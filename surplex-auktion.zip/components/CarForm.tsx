
import React, { useState, useRef } from 'react';
import { X, Upload, Camera } from 'lucide-react';
import { CarSale, CarStatus } from '../types';

interface CarFormProps {
  onSave: (car: Omit<CarSale, 'id'>) => void;
  onClose: () => void;
  initialData?: CarSale;
}

export const CarForm: React.FC<CarFormProps> = ({ onSave, onClose, initialData }) => {
  const [formData, setFormData] = useState({
    make: initialData?.make || '',
    model: initialData?.model || '',
    year: initialData?.year || new Date().getFullYear(),
    vin: initialData?.vin || '',
    arrivalDate: initialData?.arrivalDate || '',
    auctionNo: initialData?.auctionNo || '',
    purchasePrice: initialData?.purchasePrice || 0,
    status: initialData?.status || CarStatus.AVAILABLE,
    saleDate: initialData?.saleDate || '',
    salePrice: initialData?.salePrice || 0,
    fees: initialData?.fees || 0,
    notes: initialData?.notes || '',
    imageUrl: initialData?.imageUrl || '',
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData({ ...formData, imageUrl: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl my-8">
        <div className="p-6 border-b border-slate-100 flex justify-between items-center sticky top-0 bg-white z-10 rounded-t-2xl">
          <h2 className="text-xl font-bold text-slate-800">
            {initialData ? 'Edit Vehicle' : 'Add New Vehicle'}
          </h2>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
            <X className="w-6 h-6 text-slate-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Photo Upload Section */}
          <div className="flex flex-col items-center justify-center border-2 border-dashed border-slate-200 rounded-xl p-4 bg-slate-50">
            {formData.imageUrl ? (
              <div className="relative group w-full max-w-xs h-48">
                <img src={formData.imageUrl} className="w-full h-full object-cover rounded-lg shadow-md" alt="Preview" />
                <button 
                  type="button"
                  onClick={() => setFormData({...formData, imageUrl: ''})}
                  className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button 
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex flex-col items-center space-y-2 text-slate-500 hover:text-blue-600 transition-colors"
              >
                <div className="p-4 bg-white rounded-full shadow-sm">
                  <Camera className="w-8 h-8" />
                </div>
                <span className="text-sm font-medium">Add Vehicle Photo</span>
              </button>
            )}
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleImageUpload} 
              accept="image/*" 
              className="hidden" 
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-sm font-semibold text-slate-700">Make</label>
              <input type="text" required value={formData.make} onChange={e => setFormData({...formData, make: e.target.value})} className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" placeholder="e.g. Dodge" />
            </div>
            <div className="space-y-1">
              <label className="text-sm font-semibold text-slate-700">Model</label>
              <input type="text" required value={formData.model} onChange={e => setFormData({...formData, model: e.target.value})} className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" placeholder="e.g. Challenger" />
            </div>
            <div className="space-y-1">
              <label className="text-sm font-semibold text-slate-700">Year</label>
              <input type="number" required value={formData.year} onChange={e => setFormData({...formData, year: parseInt(e.target.value)})} className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" />
            </div>
            <div className="space-y-1">
              <label className="text-sm font-semibold text-slate-700">VIN</label>
              <input type="text" required value={formData.vin} onChange={e => setFormData({...formData, vin: e.target.value.toUpperCase()})} className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" placeholder="VIN Number" />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-sm font-semibold text-slate-700">Arrival Date (Nuvežimo Data)</label>
              <input type="date" value={formData.arrivalDate} onChange={e => setFormData({...formData, arrivalDate: e.target.value})} className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" />
            </div>
            <div className="space-y-1">
              <label className="text-sm font-semibold text-slate-700">Auction # (Aukciono Nr.)</label>
              <input type="text" value={formData.auctionNo} onChange={e => setFormData({...formData, auctionNo: e.target.value})} className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" />
            </div>
            <div className="space-y-1">
              <label className="text-sm font-semibold text-slate-700">Min Price / Cost ($)</label>
              <input type="number" required value={formData.purchasePrice} onChange={e => setFormData({...formData, purchasePrice: parseFloat(e.target.value)})} className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" />
            </div>
            <div className="space-y-1">
              <label className="text-sm font-semibold text-slate-700">Status</label>
              <select value={formData.status} onChange={e => setFormData({...formData, status: e.target.value as CarStatus})} className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-white">
                {Object.values(CarStatus).map(status => (
                  <option key={status} value={status}>{status}</option>
                ))}
              </select>
            </div>
          </div>

          {formData.status === CarStatus.SOLD && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-emerald-50 rounded-xl border border-emerald-100">
              <div className="space-y-1">
                <label className="text-sm font-semibold text-emerald-800">Sale Price ($)</label>
                <input type="number" value={formData.salePrice} onChange={e => setFormData({...formData, salePrice: parseFloat(e.target.value)})} className="w-full px-4 py-2 border border-emerald-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none bg-white" />
              </div>
              <div className="space-y-1">
                <label className="text-sm font-semibold text-emerald-800">Sale Date</label>
                <input type="date" value={formData.saleDate} onChange={e => setFormData({...formData, saleDate: e.target.value})} className="w-full px-4 py-2 border border-emerald-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none bg-white" />
              </div>
            </div>
          )}

          <div className="flex space-x-3 pt-4 border-t border-slate-100">
            <button type="button" onClick={onClose} className="flex-1 px-6 py-3 border border-slate-200 text-slate-700 rounded-xl font-semibold hover:bg-slate-50 transition-colors">Cancel</button>
            <button type="submit" className="flex-1 px-6 py-3 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition-all shadow-lg shadow-blue-200">Save Record</button>
          </div>
        </form>
      </div>
    </div>
  );
};


import React from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, Legend, LineChart, Line 
} from 'recharts';
import { TrendingUp, DollarSign, Package, CheckCircle, AlertCircle } from 'lucide-react';
import { CarSale, SalesStats, CarStatus } from '../types';

interface DashboardProps {
  sales: CarSale[];
  stats: SalesStats;
}

const COLORS = ['#3b82f6', '#fbbf24', '#10b981'];

export const Dashboard: React.FC<DashboardProps> = ({ sales, stats }) => {
  const statusData = [
    { name: 'Available', value: sales.filter(s => s.status === CarStatus.AVAILABLE).length },
    { name: 'Pending', value: sales.filter(s => s.status === CarStatus.PENDING).length },
    { name: 'Sold', value: sales.filter(s => s.status === CarStatus.SOLD).length },
  ];

  // Group profit by month (simplified)
  const monthlyData = sales
    .filter(s => s.status === CarStatus.SOLD && s.salePrice)
    .reduce((acc: any[], sale) => {
      const month = new Date(sale.saleDate!).toLocaleString('default', { month: 'short' });
      const profit = (sale.salePrice || 0) - sale.purchasePrice - sale.fees;
      const existing = acc.find(item => item.month === month);
      if (existing) {
        existing.profit += profit;
      } else {
        acc.push({ month, profit });
      }
      return acc;
    }, []);

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard 
          title="Total Profit" 
          value={`$${stats.totalProfit.toLocaleString()}`} 
          icon={<TrendingUp className="text-green-600" />}
          color="bg-green-50"
        />
        <StatCard 
          title="Inventory Count" 
          value={stats.inventoryCount.toString()} 
          icon={<Package className="text-blue-600" />}
          color="bg-blue-50"
        />
        <StatCard 
          title="Sold Cars" 
          value={stats.soldCount.toString()} 
          icon={<CheckCircle className="text-emerald-600" />}
          color="bg-emerald-50"
        />
        <StatCard 
          title="Avg. Profit/Car" 
          value={`$${Math.round(stats.avgProfitPerCar).toLocaleString()}`} 
          icon={<DollarSign className="text-amber-600" />}
          color="bg-amber-50"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Profit Chart */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
          <h3 className="text-lg font-semibold mb-4 text-slate-800">Monthly Profit Trends</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="profit" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Status Distribution */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
          <h3 className="text-lg font-semibold mb-4 text-slate-800">Inventory Status</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={statusData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard: React.FC<{ title: string; value: string; icon: React.ReactNode; color: string }> = ({ title, value, icon, color }) => (
  <div className={`p-4 rounded-xl border border-slate-200 bg-white flex items-center space-x-4`}>
    <div className={`p-3 rounded-lg ${color}`}>
      {icon}
    </div>
    <div>
      <p className="text-sm text-slate-500 font-medium">{title}</p>
      <p className="text-2xl font-bold text-slate-900">{value}</p>
    </div>
  </div>
);


import { GoogleGenAI, Type } from "@google/genai";
import { CarSale } from "../types";

export const analyzeSales = async (sales: CarSale[]): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `
    Analyze the following car auction sales data and provide 3-4 professional business insights or tips to increase profit. 
    Format the response as clear bullet points.
    
    Data:
    ${JSON.stringify(sales, null, 2)}
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: "You are a highly experienced automotive business consultant specializing in car auctions. Be concise and data-driven.",
        temperature: 0.7,
      },
    });

    return response.text || "Unable to generate insights at this time.";
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return "Error connecting to AI advisor. Please try again later.";
  }
};

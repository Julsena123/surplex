
import React, { useState, useEffect, useMemo } from 'react';
import { Plus, Car, LayoutDashboard, Database } from 'lucide-react';
import { CarSale, CarStatus, SalesStats } from './types';
import { Dashboard } from './components/Dashboard';
import { CarTable } from './components/CarTable';
import { CarForm } from './components/CarForm';
import { AIInsights } from './components/AIInsights';

// Data strictly from the user's screenshot
const INITIAL_SALES: CarSale[] = [
  {
    id: '1',
    make: 'Dodge',
    model: 'Challenger 3.6',
    year: 2013,
    vin: '2C3CDYAG8DH511375',
    arrivalDate: '2025-12-05',
    auctionNo: '1',
    purchasePrice: 7950,
    status: CarStatus.SOLD,
    saleDate: '2025-12-12',
    salePrice: 7950,
    fees: 0,
  },
  {
    id: '2',
    make: 'Jeep',
    model: 'Gladiator',
    year: 2021,
    vin: '1C6HJTAG5ML576384',
    arrivalDate: '2025-11-05',
    auctionNo: '2',
    purchasePrice: 28600,
    status: CarStatus.SOLD,
    saleDate: '2025-12-14',
    salePrice: 28600,
    fees: 0,
  },
  {
    id: '3',
    make: 'Dodge',
    model: 'Charger RT',
    year: 2014,
    vin: '2C3CDXJG8EH308451',
    arrivalDate: '2025-12-16',
    auctionNo: '2',
    purchasePrice: 7700,
    status: CarStatus.AVAILABLE,
    fees: 0,
  },
  {
    id: '4',
    make: 'Dodge',
    model: 'Durango RT',
    year: 2022,
    vin: '1C4SDJCT9NC204570',
    arrivalDate: '',
    auctionNo: '1',
    purchasePrice: 24300,
    status: CarStatus.AVAILABLE,
    fees: 0,
  },
  {
    id: '5',
    make: 'Dodge',
    model: 'Challenger 3.6',
    year: 2019,
    vin: '2C3CDZAG2KH718945',
    arrivalDate: '',
    auctionNo: '',
    purchasePrice: 11200,
    status: CarStatus.AVAILABLE,
    fees: 0,
  }
];

const App: React.FC = () => {
  const [sales, setSales] = useState<CarSale[]>(() => {
    const saved = localStorage.getItem('carSales_v2');
    return saved ? JSON.parse(saved) : INITIAL_SALES;
  });
  const [activeTab, setActiveTab] = useState<'dashboard' | 'inventory'>('inventory');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingCar, setEditingCar] = useState<CarSale | null>(null);

  useEffect(() => {
    localStorage.setItem('carSales_v2', JSON.stringify(sales));
  }, [sales]);

  const stats: SalesStats = useMemo(() => {
    const soldCars = sales.filter(s => s.status === CarStatus.SOLD);
    const totalProfit = soldCars.reduce((sum, car) => 
      sum + ((car.salePrice || 0) - car.purchasePrice - car.fees), 0
    );
    const totalRevenue = soldCars.reduce((sum, car) => sum + (car.salePrice || 0), 0);
    
    return {
      totalProfit,
      totalRevenue,
      avgProfitPerCar: soldCars.length > 0 ? totalProfit / soldCars.length : 0,
      soldCount: soldCars.length,
      inventoryCount: sales.filter(s => s.status !== CarStatus.SOLD).length,
    };
  }, [sales]);

  const handleSaveCar = (carData: Omit<CarSale, 'id'>) => {
    if (editingCar) {
      setSales(prev => prev.map(s => s.id === editingCar.id ? { ...carData, id: editingCar.id } : s));
    } else {
      const newCar: CarSale = {
        ...carData,
        id: Math.random().toString(36).substr(2, 9),
      };
      setSales(prev => [newCar, ...prev]);
    }
    setIsFormOpen(false);
    setEditingCar(null);
  };

  const handleDeleteCar = (id: string) => {
    if (window.confirm('Delete this record?')) {
      setSales(prev => prev.filter(s => s.id !== id));
    }
  };

  const handleEditCar = (car: CarSale) => {
    setEditingCar(car);
    setIsFormOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="bg-blue-600 p-2 rounded-lg"><Car className="text-white w-6 h-6" /></div>
            <h1 className="text-xl font-bold text-slate-900 tracking-tight hidden sm:block">AuctionCar Pro</h1>
          </div>
          
          <nav className="flex space-x-1 sm:space-x-4">
            <TabButton active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')} icon={<LayoutDashboard className="w-5 h-5" />} label="Dashboard" />
            <TabButton active={activeTab === 'inventory'} onClick={() => setActiveTab('inventory')} icon={<Database className="w-5 h-5" />} label="Vehicles" />
          </nav>

          <button onClick={() => setIsFormOpen(true)} className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-blue-700 shadow-lg shadow-blue-200"><Plus className="w-5 h-5" /><span className="hidden sm:inline">Add Car</span></button>
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto w-full p-4 sm:p-6 lg:p-8 space-y-8">
        {activeTab === 'dashboard' ? (
          <>
            <AIInsights sales={sales} />
            <Dashboard sales={sales} stats={stats} />
          </>
        ) : (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-slate-900">Vehicle Management</h2>
            <CarTable sales={sales} onEdit={handleEditCar} onDelete={handleDeleteCar} />
          </div>
        )}
      </main>

      {isFormOpen && (
        <CarForm 
          onSave={handleSaveCar} 
          onClose={() => { setIsFormOpen(false); setEditingCar(null); }}
          initialData={editingCar || undefined}
        />
      )}
    </div>
  );
};

const TabButton: React.FC<{ active: boolean; onClick: () => void; icon: React.ReactNode; label: string }> = ({ active, onClick, icon, label }) => (
  <button onClick={onClick} className={`flex items-center space-x-2 px-3 py-2 rounded-lg font-medium transition-colors ${active ? 'bg-blue-50 text-blue-700' : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'}`}>
    {icon}<span className="hidden md:inline">{label}</span>
  </button>
);

export default App;
